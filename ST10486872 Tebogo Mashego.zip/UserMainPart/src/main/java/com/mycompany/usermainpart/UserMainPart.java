/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.usermainpart;

/**
 *
 * @author RC_Student_lab
 */
import java.util.Scanner;

public class UserMainPart {
    private String username;
    private String password;
    private String firstName;
    private String phoneNumber;

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        UserMainPart app = new UserMainPart();

        // Registration process
        String registrationMessage = app.registerUser(scanner);
        System.out.println(registrationMessage);

        // Check if registration was successful before proceeding to login
        if (registrationMessage.contains("successful")) {
            System.out.print("Enter your username to log in: ");
            String loginUsername = scanner.nextLine();

            System.out.print("Enter your password: ");
            String loginPassword = scanner.nextLine();

            String loginMessage = app.authenticateUser(loginUsername, loginPassword);
            System.out.println(loginMessage);
        } else {
            System.out.println("Please try registering again.");
        }

        scanner.close();
    }

    // Method to register a user
    private String registerUser(Scanner scanner) {
        System.out.print("Please Enter your first name: ");
        firstName = scanner.nextLine();

        System.out.print("Please Enter your username (must contain an underscore and be no longer than five characters): ");
        username = scanner.nextLine();

        if (!checkUserName(username)) {
            return "Invalid username. It must contain an underscore and be no longer than five characters.";
        }

        System.out.print("Please Enter your password (at least 8 characters long): ");
        password = scanner.nextLine();

        if (!checkPasswordComplexity(password)) {
            return "Invalid password. It must be at least 8 characters long.";
        }

        System.out.print("Please Enter your South African cell phone number (must start with '+27' and be 13 characters long): ");
        phoneNumber = scanner.nextLine();

        if (!checkCellPhoneNumber(phoneNumber)) {
            return "Invalid phone number. It must start with '+27' and be exactly 13 characters long.";
        }

        return "Registration successful! You can now log in.";
    }

    // Method to authenticate a user
    private String authenticateUser(String inputUsername, String inputPassword) {
        if (inputUsername.equals(username) && inputPassword.equals(password)) {
            return "Welcome " + firstName + ", you are logged in.";
        } else {
            return "Username or password incorrect.";
        }
    }

    // Helper method to validate username
    private boolean checkUserName(String username) {
        return username.contains("_") && username.length() <= 5;
    }

    // Helper method to validate phone number
    private boolean checkCellPhoneNumber(String phoneNumber) {
        return phoneNumber.startsWith("+27") && phoneNumber.length() == 13;
    }

    // Helper method to validate password complexity
    private boolean checkPasswordComplexity(String password) {
        return password.length() >= 8; // Simple check for length
    }
}
